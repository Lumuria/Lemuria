import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { CartProvider } from './contexts/CartContext';
import { PCBuilderProvider } from './contexts/PCBuilderContext';
import GlobalStyles from './styles/GlobalStyles';
import HomePage from './pages/HomePage';
import StorePage from './pages/StorePage';
import PCBuilderPage from './pages/PCBuilderPage';

function App() {
  return (
    <Router>
      <LanguageProvider>
        <ThemeProvider>
          <CartProvider>
            <PCBuilderProvider>
              <GlobalStyles />
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/store" element={<StorePage />} />
                <Route path="/pc-builder" element={<PCBuilderPage />} />
              </Routes>
            </PCBuilderProvider>
          </CartProvider>
        </ThemeProvider>
      </LanguageProvider>
    </Router>
  );
}

export default App;

