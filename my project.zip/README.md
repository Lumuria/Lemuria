 User Guide - Gaming Store & PC Builder

## Overview

This project is a comprehensive web application built with React and TypeScript, combining an online gaming/computer accessories store with a PC building tool featuring compatibility validation. The site supports Arabic and English languages, dark mode, and is fully responsive across all devices.

## Key Features

1. **Multilingual Support**: Full Arabic/English support with seamless switching
2. **Dark Mode**: Toggle between light/dark themes
3. **Responsive Design**: Optimized for mobile phones to desktop computers
4. **E-commerce Store**: Browse and purchase gaming products & computer accessories
5. **PC Builder Tool**: Select components with automatic compatibility validation
6. **Account Management**: User registration, login, and profile management
7. **Advanced Search**: Keyword search with category/price/brand filtering
8. **Shopping Cart & Checkout**: Add/modify/remove products, complete payments
9. **Review System**: Star ratings and written product reviews
10. **Wishlist**: Save favorite products for later
11. **Product Comparison**: Compare specifications via comparison tables
12. **3D PC Assembly Preview**: Interactive 3D visualization of selected components
13. **Power & Performance Calculator**: Power consumption estimation and performance metrics
14. **Coupon System**: Apply discount codes and special offers
15. **Configuration Sharing**: Share PC builds on social media

## Project Structure

```
gaming-store/
├── public/
│   ├── locales/
│   │   ├── ar/
│   │   │   └── translation.json
│   │   └── en/
│   │       └── translation.json
│   └── index.html
├── src/
│   ├── components/
│   │   ├── CartComponent.tsx
│   │   ├── CategoryFilter.tsx
│   │   ├── Footer.tsx
│   │   ├── Header.tsx
│   │   ├── MobileResponsiveUtils.tsx
│   │   ├── PriceFilter.tsx
│   │   ├── ProductCard.tsx
│   │   ├── ProductComparison.tsx
│   │   ├── ProductGrid.tsx
│   │   ├── PromoCode.tsx
│   │   ├── Recommendations.tsx
│   │   ├── ReviewsAndRatings.tsx
│   │   ├── S